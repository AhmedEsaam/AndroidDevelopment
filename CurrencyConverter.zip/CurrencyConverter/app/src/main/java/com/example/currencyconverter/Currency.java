package com.example.currencyconverter;

public class Currency {

    private float currency;

    public float getCurrency() { return currency; }

    public void setCurrency(float currency) {
        this.currency = currency;
    }

    public float convertToEg() { return (currency * 16); }
    public float convertToUS() { return (currency / 16f); }


}
