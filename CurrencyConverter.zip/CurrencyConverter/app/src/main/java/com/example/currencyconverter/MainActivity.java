package com.example.currencyconverter;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {

    TextInputEditText usInput;
    TextInputEditText egInput;
    Button clear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usInput = findViewById(R.id.US_input);
        egInput = findViewById(R.id.EG_input);
        clear = findViewById(R.id.ClearButton);

        usInput.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                String InputStr = usInput.getText().toString();
                if (!InputStr.isEmpty()) {
                    float InputFloat = Float.parseFloat(InputStr);
                    Currency currency = new Currency();
                    currency.setCurrency(InputFloat);
                    InputFloat = currency.convertToEg();
                    egInput.setText(String.valueOf(InputFloat));
                } else {
                    egInput.setText(null);
                }
                return false;
            }
        });


        egInput.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                String InputStr = egInput.getText().toString();
                if (!InputStr.isEmpty()) {
                    float InputFloat = Float.parseFloat(InputStr);
                    Currency currency = new Currency();
                    currency.setCurrency(InputFloat);
                    InputFloat = currency.convertToUS();
                    usInput.setText(String.valueOf(InputFloat));
                } else {
                    usInput.setText(null);
                }
                return false;
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usInput.setText(null);
                egInput.setText(null);
            }
        });
    }
}